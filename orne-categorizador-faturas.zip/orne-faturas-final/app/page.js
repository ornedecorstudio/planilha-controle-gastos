'use client';

import { useState } from 'react';

const CATEGORIAS = [
  'Marketing Digital',
  'Pagamento Fornecedores', 
  'Taxas Checkout',
  'Compra de Câmbio',
  'IA e Automação',
  'Telefonia',
  'ERP',
  'Gestão',
  'Viagem',
  'Outros'
];

const ORIGENS = [
  'Amex 2483', 'XP 9560', 'Unique MC 4724', 'Unique Visa 6910',
  'Gol Smiles 8172', 'Elite 7197', 'Nubank 1056', 'Latam 1643',
  'C6 5839', 'C6 8231', 'Azul Itaú 4626', 'MP 5415',
  'Transferência PJ', 'PIX PJ', 'Boleto PJ'
];

const CATEGORY_COLORS = {
  'Marketing Digital': 'bg-blue-100 text-blue-800 border-blue-300',
  'Pagamento Fornecedores': 'bg-purple-100 text-purple-800 border-purple-300',
  'Taxas Checkout': 'bg-yellow-100 text-yellow-800 border-yellow-300',
  'Compra de Câmbio': 'bg-green-100 text-green-800 border-green-300',
  'IA e Automação': 'bg-indigo-100 text-indigo-800 border-indigo-300',
  'Telefonia': 'bg-pink-100 text-pink-800 border-pink-300',
  'ERP': 'bg-orange-100 text-orange-800 border-orange-300',
  'Gestão': 'bg-teal-100 text-teal-800 border-teal-300',
  'Viagem': 'bg-cyan-100 text-cyan-800 border-cyan-300',
  'Outros': 'bg-gray-100 text-gray-800 border-gray-300'
};

export default function Home() {
  const [step, setStep] = useState(1);
  const [rawData, setRawData] = useState('');
  const [transactions, setTransactions] = useState([]);
  const [aggregatedData, setAggregatedData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [selectedOrigem, setSelectedOrigem] = useState('');
  const [anoAtual, setAnoAtual] = useState(new Date().getFullYear().toString());

  // Parser melhorado para diferentes formatos de fatura
  const parseData = (text) => {
    const lines = text.trim().split('\n').filter(line => line.trim());
    const parsed = [];
    
    for (const line of lines) {
      // Padrão 1: "06/01 FACEBK *MQ5BKB9CD2SAO P 171,14 serviços SAO PAULO"
      let match = line.match(/(\d{2}\/\d{2})\s+(.+?)\s+([\d.,]+)\s*(?:serviços|viagem|compras|outros|pagamento)?/i);
      
      // Padrão 2: "06/01/2026 FACEBK *MQ5BKB9CD2SAO 171,14"
      if (!match) {
        match = line.match(/(\d{2}\/\d{2}(?:\/\d{2,4})?)\s+(.+?)\s+([\d.,]+)\s*$/i);
      }
      
      // Padrão 3: CSV com separador ;
      if (!match && line.includes(';')) {
        const parts = line.split(';');
        if (parts.length >= 3) {
          const dataMatch = parts[0].match(/(\d{2}\/\d{2})/);
          if (dataMatch) {
            match = [null, dataMatch[1], parts[1], parts[2].replace(/[^\d,.-]/g, '')];
          }
        }
      }

      if (match) {
        let [_, data, descricao, valorStr] = match;
        // Normalizar data para DD/MM
        if (data.length > 5) {
          data = data.substring(0, 5);
        }
        // Normalizar valor
        valorStr = valorStr.replace(/\./g, '').replace(',', '.');
        const valor = parseFloat(valorStr);
        
        if (!isNaN(valor) && valor > 0) {
          parsed.push({
            id: Math.random().toString(36).substr(2, 9),
            data: data,
            descricao: descricao.trim(),
            valor: valor,
            categoria: '',
            incluir: true
          });
        }
      }
    }
    return parsed;
  };

  const handleProcessar = async () => {
    if (!rawData.trim()) {
      setError('Cole os dados da fatura primeiro');
      return;
    }
    if (!selectedOrigem) {
      setError('Selecione o cartão de origem');
      return;
    }

    setError('');
    setLoading(true);

    const parsed = parseData(rawData);
    
    if (parsed.length === 0) {
      setError('Não foi possível extrair transações. Verifique o formato dos dados.');
      setLoading(false);
      return;
    }

    try {
      // Chamar API de categorização
      const response = await fetch('/api/categorize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transacoes: parsed })
      });

      const result = await response.json();
      
      if (result.categorias && result.categorias.length > 0) {
        const categorizados = parsed.map((t, i) => ({
          ...t,
          categoria: result.categorias[i] || 'Outros'
        }));
        setTransactions(categorizados);
      } else {
        // Fallback: manter sem categoria
        setTransactions(parsed.map(t => ({ ...t, categoria: 'Outros' })));
      }
      
      setStep(2);
    } catch (err) {
      console.error('Erro:', err);
      // Em caso de erro, continua com categorização básica
      setTransactions(parsed.map(t => ({ ...t, categoria: 'Outros' })));
      setStep(2);
    } finally {
      setLoading(false);
    }
  };

  const handleAgregar = () => {
    const grupos = {};
    
    transactions
      .filter(t => t.incluir)
      .forEach(t => {
        const key = `${t.data}_${t.categoria}`;
        if (!grupos[key]) {
          grupos[key] = {
            data: t.data,
            categoria: t.categoria,
            valor: 0,
            qtd: 0,
            descricoes: []
          };
        }
        grupos[key].valor += t.valor;
        grupos[key].qtd += 1;
        grupos[key].descricoes.push(t.descricao);
      });

    const agregados = Object.values(grupos)
      .map(g => ({
        id: Math.random().toString(36).substr(2, 9),
        data: `${g.data}/${anoAtual}`,
        categoria: g.categoria,
        detalhe: g.qtd > 1 ? `${g.categoria} (${g.qtd} transações)` : g.descricoes[0].substring(0, 50),
        origem: selectedOrigem,
        valor: g.valor,
        obs: g.qtd > 1 ? `Agregado: ${g.qtd} lançamentos` : ''
      }))
      .sort((a, b) => a.data.localeCompare(b.data));

    setAggregatedData(agregados);
    setStep(3);
  };

  const handleEnviarParaPlanilha = async () => {
    setSending(true);
    setError('');
    setSuccess('');

    try {
      const response = await fetch('/api/sheets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dados: aggregatedData,
          sheetName: 'Movimentação'
        })
      });

      const result = await response.json();

      if (result.success) {
        setSuccess(`✅ ${result.message}`);
        // Limpar após sucesso
        setTimeout(() => {
          setStep(1);
          setRawData('');
          setTransactions([]);
          setAggregatedData([]);
          setSuccess('');
        }, 3000);
      } else {
        setError(result.error || 'Erro ao enviar dados');
      }
    } catch (err) {
      setError('Erro de conexão. Tente novamente.');
    } finally {
      setSending(false);
    }
  };

  const handleExportCSV = () => {
    const header = 'DATA,CATEGORIA,DETALHE,ORIGEM,VALOR,OBS';
    const rows = aggregatedData.map(r => 
      `${r.data},"${r.categoria}","${r.detalhe}","${r.origem}",${r.valor.toFixed(2)},"${r.obs}"`
    );
    const csv = [header, ...rows].join('\n');
    
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `movimentacao_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  const toggleIncluir = (id) => {
    setTransactions(prev => prev.map(t => 
      t.id === id ? { ...t, incluir: !t.incluir } : t
    ));
  };

  const updateCategoria = (id, categoria) => {
    setTransactions(prev => prev.map(t =>
      t.id === id ? { ...t, categoria } : t
    ));
  };

  const updateAggregated = (id, field, value) => {
    setAggregatedData(prev => prev.map(r =>
      r.id === id ? { ...r, [field]: field === 'valor' ? parseFloat(value) || 0 : value } : r
    ));
  };

  const totalSelecionado = transactions.filter(t => t.incluir).reduce((acc, t) => acc + t.valor, 0);
  const totalAgregado = aggregatedData.reduce((acc, r) => acc + r.valor, 0);

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-800 to-slate-700 text-white p-6 rounded-t-xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-500 rounded-lg flex items-center justify-center font-bold text-xl">O</div>
            <div>
              <h1 className="text-2xl font-bold">ORNE - Categorizador de Faturas</h1>
              <p className="text-slate-300 text-sm">Categorização automática com IA + Integração Google Sheets</p>
            </div>
          </div>
        </div>

        {/* Progress */}
        <div className="bg-white border-b px-6 py-4 flex items-center gap-4">
          {[
            { num: 1, label: 'Upload', icon: '📄' },
            { num: 2, label: 'Revisar', icon: '✏️' },
            { num: 3, label: 'Enviar', icon: '📤' }
          ].map((s, i) => (
            <div key={s.num} className="flex items-center gap-2 flex-1">
              <div className={`flex items-center gap-2 ${step >= s.num ? 'text-slate-800' : 'text-gray-400'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all
                  ${step > s.num ? 'bg-green-500 text-white' : step === s.num ? 'bg-amber-500 text-white' : 'bg-gray-200'}`}>
                  {step > s.num ? '✓' : s.icon}
                </div>
                <span className="font-medium hidden sm:inline">{s.label}</span>
              </div>
              {i < 2 && <div className={`flex-1 h-1 rounded mx-2 ${step > s.num ? 'bg-green-500' : 'bg-gray-200'}`} />}
            </div>
          ))}
        </div>

        {/* Content */}
        <div className="bg-white p-6 rounded-b-xl shadow-lg">
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
              <span>⚠️</span> {error}
            </div>
          )}
          
          {success && (
            <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
              {success}
            </div>
          )}

          {/* Step 1: Upload */}
          {step === 1 && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Cartão de Origem *
                  </label>
                  <select 
                    value={selectedOrigem}
                    onChange={(e) => setSelectedOrigem(e.target.value)}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  >
                    <option value="">Selecione o cartão...</option>
                    {ORIGENS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Ano da Fatura
                  </label>
                  <input
                    type="text"
                    value={anoAtual}
                    onChange={(e) => setAnoAtual(e.target.value)}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-amber-500"
                    placeholder="2026"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Cole os dados da fatura (copiados do extrato ou CSV)
                </label>
                <textarea
                  value={rawData}
                  onChange={(e) => setRawData(e.target.value)}
                  placeholder={`Cole aqui os dados da fatura. Exemplos de formatos aceitos:

06/01 FACEBK *MQ5BKB9CD2SAO P 171,14 serviços SAO PAULO
06/01 FACEBK *QBQXG9HCD2SAO P 171,80 serviços SAO PAULO
07/01 Azul Linhas Aereas Bras 309,60 viagem Baureri
09/01 ALIEXPRESS 1.250,00 compras`}
                  className="w-full h-64 p-4 border rounded-lg font-mono text-sm focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <button
                onClick={handleProcessar}
                disabled={loading || !selectedOrigem || !rawData.trim()}
                className="flex items-center justify-center gap-2 w-full md:w-auto px-6 py-3 bg-amber-500 text-white rounded-lg hover:bg-amber-600 disabled:opacity-50 disabled:cursor-not-allowed font-medium transition-colors"
              >
                {loading ? (
                  <>
                    <span className="animate-spin">⏳</span>
                    Processando com IA...
                  </>
                ) : (
                  <>
                    <span>🤖</span>
                    Processar e Categorizar
                  </>
                )}
              </button>
            </div>
          )}

          {/* Step 2: Review */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="font-semibold text-lg">Revise as Categorias</h3>
                  <p className="text-sm text-gray-500">
                    {transactions.filter(t => t.incluir).length} de {transactions.length} selecionadas | 
                    Total: <span className="font-bold text-green-600">R$ {totalSelecionado.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                  </p>
                </div>
                <button onClick={() => setStep(1)} className="text-sm text-amber-600 hover:underline">
                  ← Voltar
                </button>
              </div>

              <div className="overflow-x-auto border rounded-lg">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="p-3 text-left w-12">✓</th>
                      <th className="p-3 text-left">Data</th>
                      <th className="p-3 text-left">Descrição</th>
                      <th className="p-3 text-left">Categoria</th>
                      <th className="p-3 text-right">Valor</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map(t => (
                      <tr key={t.id} className={`border-t hover:bg-gray-50 ${!t.incluir ? 'opacity-40 bg-gray-100' : ''}`}>
                        <td className="p-3">
                          <input
                            type="checkbox"
                            checked={t.incluir}
                            onChange={() => toggleIncluir(t.id)}
                            className="w-4 h-4 rounded accent-amber-500"
                          />
                        </td>
                        <td className="p-3 font-mono text-xs">{t.data}</td>
                        <td className="p-3 max-w-xs truncate text-xs" title={t.descricao}>{t.descricao}</td>
                        <td className="p-3">
                          <select
                            value={t.categoria}
                            onChange={(e) => updateCategoria(t.id, e.target.value)}
                            className={`px-2 py-1 rounded text-xs font-medium border ${CATEGORY_COLORS[t.categoria] || 'bg-gray-100'}`}
                          >
                            {CATEGORIAS.map(c => <option key={c} value={c}>{c}</option>)}
                          </select>
                        </td>
                        <td className="p-3 text-right font-mono font-medium">
                          R$ {t.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <button
                onClick={handleAgregar}
                className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium"
              >
                <span>✅</span>
                Agregar por Dia/Categoria e Continuar
              </button>
            </div>
          )}

          {/* Step 3: Export */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="font-semibold text-lg">Dados Agregados - Prontos para Enviar</h3>
                  <p className="text-sm text-gray-500">
                    {aggregatedData.length} lançamentos | 
                    Total: <span className="font-bold text-green-600">R$ {totalAgregado.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                  </p>
                </div>
                <button onClick={() => setStep(2)} className="text-sm text-amber-600 hover:underline">
                  ← Voltar
                </button>
              </div>

              <div className="overflow-x-auto border rounded-lg">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="p-3 text-left">Data</th>
                      <th className="p-3 text-left">Categoria</th>
                      <th className="p-3 text-left">Detalhe</th>
                      <th className="p-3 text-left">Origem</th>
                      <th className="p-3 text-right">Valor</th>
                      <th className="p-3 text-left">Obs</th>
                    </tr>
                  </thead>
                  <tbody>
                    {aggregatedData.map(r => (
                      <tr key={r.id} className="border-t hover:bg-gray-50">
                        <td className="p-3 font-mono text-xs">{r.data}</td>
                        <td className="p-3">
                          <span className={`px-2 py-1 rounded text-xs font-medium ${CATEGORY_COLORS[r.categoria]}`}>
                            {r.categoria}
                          </span>
                        </td>
                        <td className="p-3">
                          <input
                            type="text"
                            value={r.detalhe}
                            onChange={(e) => updateAggregated(r.id, 'detalhe', e.target.value)}
                            className="w-full p-1 border rounded text-xs"
                          />
                        </td>
                        <td className="p-3">
                          <select
                            value={r.origem}
                            onChange={(e) => updateAggregated(r.id, 'origem', e.target.value)}
                            className="p-1 border rounded text-xs"
                          >
                            {ORIGENS.map(o => <option key={o} value={o}>{o}</option>)}
                          </select>
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-green-600">
                          R$ {r.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="p-3 text-xs text-gray-500">{r.obs}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex flex-wrap gap-3">
                <button
                  onClick={handleEnviarParaPlanilha}
                  disabled={sending}
                  className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 font-medium"
                >
                  {sending ? (
                    <>
                      <span className="animate-spin">⏳</span>
                      Enviando...
                    </>
                  ) : (
                    <>
                      <span>📤</span>
                      Enviar para Google Sheets
                    </>
                  )}
                </button>
                
                <button
                  onClick={handleExportCSV}
                  className="flex items-center gap-2 px-6 py-3 bg-slate-600 text-white rounded-lg hover:bg-slate-700 font-medium"
                >
                  <span>💾</span>
                  Baixar CSV
                </button>
                
                <button
                  onClick={() => {
                    setStep(1);
                    setRawData('');
                    setTransactions([]);
                    setAggregatedData([]);
                  }}
                  className="flex items-center gap-2 px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 font-medium"
                >
                  <span>➕</span>
                  Nova Fatura
                </button>
              </div>

              <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <h4 className="font-medium text-amber-900 mb-1">💡 Dica</h4>
                <p className="text-sm text-amber-800">
                  Os dados serão adicionados na aba "Movimentação" da planilha. Você pode editar qualquer campo antes de enviar.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="text-center mt-4 text-sm text-gray-500">
          ORNE Decor Studio © {new Date().getFullYear()} | Ferramenta interna
        </div>
      </div>
    </div>
  );
}
